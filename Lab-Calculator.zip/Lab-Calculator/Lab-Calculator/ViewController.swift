//
//  ViewController.swift
//  Lab-Calculator
//
//  Created by Aidan Housenbold on 10/28/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

